#this program is to calculate insurance claim 
#date writen Nov. 21 - Nov. 26 2023
#Author Evan Pittman

#imports
import datetime

#Constances
NEXT_POLICY_NUM = 1944
BASIC_PREMIUM = 869.00
DISCOUNT_FOR_OTHER_CARS = 0.25
EXTRA_LIABILITY = 130.00
GLASS_COVERAGE = 86.00
COST_LOANER_CAR = 58.00
HST_RATE = 0.15
MONTH_PAY = 39.99

#functions
def cardiscount():
    #this is to calc the extra car discount
    Discountprice = BASIC_PREMIUM - (BASIC_PREMIUM * DISCOUNT_FOR_OTHER_CARS)
    Extracardiscount = Discountprice * (numcars - 1)
    totalextracardiscount = Extracardiscount + BASIC_PREMIUM
    return totalextracardiscount
    

def extracost():
    #this is to calc the total extra cost
    Extracost = (ExLibilityCost * numcars) + (Glasscovercost* numcars) + (Loancarcost * numcars)
    return Extracost

def monthypayment():
    #this is the calc for the monthy payments 
    if payment == "Monthly":
        monthpayment = (MONTH_PAY + totalcost)/8
    elif payment == "Down":
        monthpayment = ((totalcost - Downpay) + MONTH_PAY)/8
    else:
        monthpayment = 0
    return monthpayment

#Main program

#list
provlst=["NL","NS","PE","NB","AB","BC","MB","NT","NU","ON"," QC","SQ","YT"]
paylst = ["Full","Monthly","Down"]
claimdatelst = ["2015-12-12","2020-11-11","2023-10-10"]
claimcostlst = ["$50,000.00","$21,000.00","$15,000.00"]

while True:
    while True:
        firstname = "Evan"#input("What is the first name: ").title()
        if firstname == "":
            print("Cannot be empty")
        else:
            break
    while True:
        lastname = "Pittman"#input("What is the last name: ").title()
        if lastname =="":
            print("Cannot be empty")
        else:
            break
    
    while True:
        address = "18 park st."#input("What is the address name: ")
        if address == "":
            print("Cannot be empty")
        else:
            break
    while True:
        city = "st.johns"#input("What is the city name: ").title()
        if city == "":
            print("Cannot be empty")
        else:
            break           

    while True:
        prov = "NL"#input("what prov ").upper()
        if prov == "":
            print("no mt")
        elif len(prov) != 2:
            print("no big")
        elif prov not in provlst:
            print("got be list")
        else:
            break
    
    while True:
        postal = "A2B1C7"#input("enter postal (X9X9X9): ").upper()#go see if can valid
        if postal == "":
            print("Cannot be empty")
        else:
            break

    while True:
        Phonenum = "1234567890"#input("Enter phone number (9999999999): ")
        if Phonenum == "":
            print("cannot be empty")  
        elif Phonenum.isdigit() == False:
            print("Must be Numbers do it again")    
        elif len(Phonenum) != 10:
            print("Must be 10 chracters")
        else:
            break
    
    while True:
        try:
            numcars = int(input("How many cars: "))
        except:
            print("not a valid number try again")
        else:
            break
    
    while True:#might need re doing????
        ExLibility = "Y"#input("do you want extra liability (Y/N): ").upper()
        if ExLibility == "":
            print("cannot be empty")
        elif ExLibility == "Y":
            ExLibilityCost = EXTRA_LIABILITY
            ExLibilityYN = "Yes"
            break
        elif ExLibility == "N":
            ExLibilityCost = 0.00
            ExLibilityYN = "No"
            break
    
    while True:#might need re doing????
        Glasscover = "Y"#input("do you want glass coverage (Y/N): ").upper()
        if Glasscover == "":
            print("cannot be empty")
        elif Glasscover == "Y":
            Glasscovercost = GLASS_COVERAGE
            GlasscoverYN = "Yes"
            break
        elif Glasscover == "N":
            Glasscovercost = 0.00
            GlasscoverYN = "No"
            break

    while True:#might need re doing????
        Loancar = "Y"#input("do you want loaner car (Y/N): ").upper()
        if Loancar == "":
            print("cannot be empty")
        elif Loancar == "Y":
            Loancarcost = COST_LOANER_CAR
            LoancarYN = "Yes"
            break
        elif Loancar == "N":
            Loancarcost = 0.00
            LoancarYN = "No"
            break
    
    while True:
        payment = "Full"#input("What payment method (Full,Monthly or Down) ").title()
        if payment not in paylst:
            print("got be list")
        elif payment == "Down":
            Downpay = int(input("Enter the amount of the down payment: "))
            break
        else:
            break
    
    while True:
        Claimdate = "2023-11-26"#input("Enter the claim date (YYYY-MM-DD): ")
        try:
            Claimdate = datetime.datetime.strptime(Claimdate, "%Y-%m-%d")
            Claimdatedsp = (Claimdate.strftime("%Y-%m-%d"))
            claimdatelst.append(Claimdatedsp)
        except:
            print("Incorrect date try again")
        else:
            break
    
    while True:
        try:
            claimcost = int(input("what is the claim cost: "))
            claimcostdsp = "${:,.2f}".format(claimcost)
            claimcostlst.append(claimcostdsp)
        except:
            print("not a valid cost")
        else:
            break
    Cont = "N"#input("do you want to make another claim (Y/N): ").upper()
    if Cont == "N":
        break
#calculations 
totcardiscount = cardiscount()

totexcost = extracost()

totpremiumcost = BASIC_PREMIUM + totcardiscount + totexcost

HST = totpremiumcost * HST_RATE

totalcost = totpremiumcost + HST

invoice = datetime.datetime.now()
invoicedsp = (invoice.strftime("%B %d, %Y "))
firstpay = invoice + datetime.timedelta(days = 30)
firstpaydsp = (firstpay.strftime("%d-%b-%y"))

fullname = firstname + " " + lastname
fulladdress = prov + " " + city + " " + address + " " + postal
 
monthpay = monthypayment()



print()
print(f"          One Stop Insurance Company")
print()
print(f"Invoice Date:              {invoicedsp:<14s}") 
print()
print(f"Full Name and Address:")         
print()
print(f"{fullname:<12s}, {fulladdress:<12s}")
print()
print(f"Phone Number: {Phonenum:<10s}")
print()
print(f"Number of cars:                            {numcars:<2}")
print(f"Extra Liability:                         {ExLibilityYN:<3s}")
print(f"Glass Coverage:                          {ExLibilityYN:<3s}")
print(f"Loaner Car:                              {ExLibilityYN:<3s}")
print()
if payment == "Full":
    print(f"Payment:                                {payment:<7s}")
elif payment == "Monthly":
    print(f"Payment:                             {payment:<7s}")
elif payment == "Down":
    print(f"Payment:                                {payment:<7s}")
    Downpaydsp = "${:,.2f}".format(Downpay)
    print(f"Payment:                           {Downpaydsp:<9s}")
print()
BASIC_PREMIUMDSP = "${:,.2f}".format(BASIC_PREMIUM)
print(f"Premium:                             {BASIC_PREMIUMDSP}")
totcardiscountdsp = "${:,.2f}".format(totcardiscount)
if numcars > 1:
    print(f"Discounted total price:            {totcardiscountdsp}")

print(f"--------------------------------------------")
EXTRA_LIABILITYDSP= "${:,.2f}".format(EXTRA_LIABILITY)

print(f"Extra Liability (Per car):           {EXTRA_LIABILITYDSP}")

GLASS_COVERAGEDSP= "${:,.2f}".format(GLASS_COVERAGE)

print(f"Glass Coverage (Per car):             {GLASS_COVERAGEDSP}")

COST_LOANER_CARDSP= "${:,.2f}".format(COST_LOANER_CAR)

print(f"Loaner Car (Per car):                 {COST_LOANER_CARDSP}")

totexcostdsp= "${:,.2f}".format(totexcost)
print(f"Total Extra Cost:                    {totexcostdsp}")
print(f"--------------------------------------------")
totpremiumcostdsp= "${:,.2f}".format(totpremiumcost)
print(f"Total Insurance Premium:           {totpremiumcostdsp}")
HSTDSP= "${:,.2f}".format(HST)
print(f"HST:                                 {HSTDSP}")
totalcostdsp= "${:,.2f}".format(totalcost)
print(f"Total Cost:                        {totalcostdsp}")
print(f"--------------------------------------------")
MONTH_PAYDSP= "${:,.2f}".format(MONTH_PAY)
print(f"Processing Fee for Monthly Payment:   {MONTH_PAYDSP}")
monthpaydsp= "${:,.2f}".format(monthpay)
if payment == "Full":
    print(f"Monthly Payment:                       {monthpaydsp}")
elif payment == "Monthly":
    print(f"Monthly Payment:                     {monthpaydsp}")
elif payment == "Down":
    print(f"Monthly Payment:                     {monthpaydsp}")
print()
print(f"First Payment:                     {firstpaydsp}")
print(f"--------------------------------------------")
print()
print(f"    Claim #    Claim Date      Amount")
print(f"    ---------------------------------")
claimnum =1

for claim in range(len(claimdatelst)):
    print(f"      {str(claimnum)}.       {claimdatelst[claim]}  {claimcostlst[claim]}")
    claimnum +=1



            
