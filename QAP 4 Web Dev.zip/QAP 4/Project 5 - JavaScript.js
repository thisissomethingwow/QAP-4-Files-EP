const motelperson = {
    first: 'Evan',
    last: 'Pittman',
    birthyear: 2005,
    birth: '2-11',
    gender: 'Male',
    roompref: ['2 beds' , ' pullout bed', ' 4th floor', ' facing parking lot '],
    paymeth: 'Credit Card',
    address: {
        street: '23 Church st.',
        prov: 'Newfoundland',
        city: 'St. Johns',
        postal: 'A3C5F7',
        country: 'Canada'
    },
    phonenum: '489-5658',
    checkdates: {
        indate: new Date(20-11-2023),
        outdate: new Date(25-11-2023)
    },
    getAge: function(){
        const today = new Date();
        return today.getFullYear() - this.birthyear;
    },
    getStay: function(){
        const today = new Date();
        return 
    }
}


let age;
age = motelperson.getAge()
let totalduration;
totalduration = motelperson.checkdates.outdate - motelperson.checkdates.indate



console.log(age + ' ' + 'years old' + ' ' + 'and' ,totalduration + ' ' + 'days total stay')

html = `
    <p>
    ${motelperson.first} ${motelperson.last} was born on ${motelperson.birth}-${motelperson.birthyear} and is ${age} years old
    ${motelperson.first} is a ${motelperson.gender} and has the room peferance of ${motelperson.roompref} 
    and is using the payment method of ${motelperson.paymeth} and is staying in the room for ${totalduration} days.

</p>

`
console.log(html);
document.body.innerHTML = html